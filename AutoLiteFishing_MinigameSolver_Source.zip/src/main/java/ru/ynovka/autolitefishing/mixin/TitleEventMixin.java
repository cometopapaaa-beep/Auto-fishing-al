package ru.ynovka.autolitefishing.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ynovka.autolitefishing.TitleMessageEvents;

@Mixin(InGameHud.class)
public class TitleEventMixin {

    @Inject(method = "setTitle", at = @At("HEAD"))
    private void onSetTitle(Text title, CallbackInfo ci) {
        TitleMessageEvents.onTitleReceived(title);
    }

    @Inject(method = "setOverlayMessage", at = @At("HEAD"))
    private void onSetOverlayMessage(Text message, boolean tinted, CallbackInfo ci) {
        // Menangkap teks Actionbar
        TitleMessageEvents.onTitleReceived(message);
    }
}
