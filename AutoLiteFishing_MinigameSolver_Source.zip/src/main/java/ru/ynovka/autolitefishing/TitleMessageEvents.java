package ru.ynovka.autolitefishing;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

public class TitleMessageEvents {

    private static long lastClickTime = 0;
    private static final long CLICK_COOLDOWN_MS = 150; // Delay cooldown per-klik

    public static void onTitleReceived(Text titleText) {
        if (titleText == null) return;

        String rawText = titleText.getString();
        
        // Cek apakah teks mengandung pola indikator minigame
        if (isMinigameBar(rawText)) {
            solveMinigame(titleText, rawText);
        }
    }

    private static boolean isMinigameBar(String text) {
        // Deteksi simbol khas minigame memancing (seperti emoji api, kotak-kotak bar, dll)
        return text.contains("🔥") || text.contains("■") || text.contains("▌") || text.contains("|");
    }

    private static void solveMinigame(Text fullText, String rawText) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.interactionManager == null) return;

        // 1. Ekstraksi Posisi Target & Posisi Cursor/Pointer
        int targetIndex = findTargetZone(fullText, rawText);
        int pointerIndex = findPointerPosition(fullText, rawText);

        // 2. Jika Pointer berada tepat di Target Zone (atau toleransi +- 1 karakter untuk kompensasi ping)
        if (targetIndex != -1 && pointerIndex != -1) {
            int distance = Math.abs(pointerIndex - targetIndex);
            
            if (distance <= 1) { // Hit target area
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastClickTime >= CLICK_COOLDOWN_MS) {
                    // Eksekusi Klik Kanan Otomatis
                    client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
                    lastClickTime = currentTime;
                }
            }
        }
    }

    private static int findTargetZone(Text text, String rawText) {
        // Contoh logika: Mencari indeks karakter dengan format warna Merah/Hijau di tengah bar
        // Pada implementasi riil, ini meng-inspect TextComponent formatting
        int redIndex = rawText.indexOf("🔥"); // Indikator target zone
        return redIndex;
    }

    private static int findPointerPosition(Text text, String rawText) {
        // Mencari posisi karakter pointer yang bergerak
        // Contoh: mencari karakter khusus atau warna aktif
        for (int i = 0; i < rawText.length(); i++) {
            char c = rawText.charAt(i);
            if (c == '█' || c == '🔴' || c == '▌') {
                return i;
            }
        }
        return -1;
    }
}
