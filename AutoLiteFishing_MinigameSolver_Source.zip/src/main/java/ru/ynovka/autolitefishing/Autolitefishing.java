package ru.ynovka.autolitefishing;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Autolitefishing implements ModInitializer {
    public static final String MOD_ID = "autolitefishing";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("AutoLiteFishing Minigame Solver Initialized!");
    }
}
