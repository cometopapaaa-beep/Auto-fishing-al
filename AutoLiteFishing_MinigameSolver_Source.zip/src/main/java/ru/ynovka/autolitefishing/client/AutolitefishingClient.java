package ru.ynovka.autolitefishing.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class AutolitefishingClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Init client listeners
    }
}
